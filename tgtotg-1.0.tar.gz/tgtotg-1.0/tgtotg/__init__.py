from telethon import TelegramClient, events
from dotenv import load_dotenv
import os
import sys



print('\n\nScript em Python feito por Érico Netto')
print('Cliente do WORKANA: Thiago Pereira')
print('Data de criação: 04/06/2018\n\n\n')

print(sys.argv)
if not len(sys.argv)==2:
    print('\n>Parâmetros incorretos ou faltando, o arquivo não encontrado!')
    sys.exit()


print('\n\nIncio do script!\n')

print('>Parâmetros passados: \n')
print(' Config file: ' + sys.argv[1] +"\n")

load_dotenv(sys.argv[1])

# Use your own values here
api_id = os.getenv("APP_ID") 
api_hash = os.getenv("API_HASH") 
my_phone =os.getenv("MY_PHONE")

originChannels = os.getenv("ORIGIN_CHANNELS").split(",") #['Teste Erico 1', 'TesteErico2']
destinyChannel = os.getenv("DESTINY_CHANNEL") #'teste 3 admin'
############################################################
def main():

    client = TelegramClient('tgtotg', api_id, api_hash, update_workers=1, spawn_read_thread=False)

    if client.connect():
        if not client.is_user_authorized():
            phone_number = my_phone
            client.send_code_request(phone_number)
            myself = client.sign_in(phone_number, input('Enter code: '))



    @client.on(events.NewMessage)
    def my_event_handler(event):
        if event.chat.title in originChannels:
            client.forward_messages(destinyChannel, event.message)

    client.idle()

if __name__ == '__main__':
    main()