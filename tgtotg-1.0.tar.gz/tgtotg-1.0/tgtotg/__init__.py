from telethon import TelegramClient, events
from dotenv import load_dotenv
import os

load_dotenv('.env')
# Use your own values here
api_id = os.getenv("APP_ID") #281814
api_hash = os.getenv("API_HASH") # '74d13240efdd76ee9d00883d6c16f2b5'
my_phone =os.getenv("MY_PHONE") #'+5511976482202'

originChannels = ['Teste Erico 1', 'TesteErico2']
destinyChannel = 'teste 3 admin'



############################################################
def main():

    client = TelegramClient('tgtotg', api_id, api_hash, update_workers=1, spawn_read_thread=False)

    if client.connect():
        if not client.is_user_authorized():
            phone_number = my_phone
            client.send_code_request(phone_number)
            myself = client.sign_in(phone_number, input('Enter code: '))



    @client.on(events.NewMessage)
    def my_event_handler(event):
        if event.chat.title in originChannels:
            client.forward_messages(destinyChannel, event.message)

    client.idle()

if __name__ == '__main__':
    main()