from distutils.core import setup
setup(name='tgtotg',
      version='1.0',
      packages=['tgtotg'],
      data_files=[('.', ['.env'])],
      entry_points={'console_scripts': ['tgtotg = tgtotg:main']},
      install_requires=['python-dotenv', 'Telethon']
      )